package com.example.rentpecar.service;

import com.example.rentpecar.model.Car;
import com.example.rentpecar.model.Payment;
import com.example.rentpecar.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final CarService carService;

    @Autowired
    public PaymentService(PaymentRepository paymentRepository, CarService carService) {
        this.paymentRepository = paymentRepository;
        this.carService = carService;
    }

    public Payment processPayment(Payment payment) {

        Payment savedPayment = paymentRepository.save(payment);


        carService.setCarAvailability(payment.getCarId(), false);

        return savedPayment;
    }
}
