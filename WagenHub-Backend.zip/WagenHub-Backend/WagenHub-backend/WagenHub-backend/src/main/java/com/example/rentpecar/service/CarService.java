package com.example.rentpecar.service;

import com.example.rentpecar.model.Car;
import com.example.rentpecar.repository.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CarService {

    private final CarRepository carRepository;

    @Autowired
    public CarService(CarRepository carRepository) {
        this.carRepository = carRepository;
    }

    public Car createCar(Car car) {
        return carRepository.save(car);
    }

    public Car getCarById(Long id) {
        return carRepository.findById(id).orElseThrow(() -> new RuntimeException("Car not found"));
    }

    public List<Car> getAllAvailableCars() {
        return carRepository.findByAvailableTrue();
    }

    public Car updateCar(Long id, Car car) {
        if (!carRepository.existsById(id)) {
            throw new RuntimeException("Car not found");
        }
        car.setId(id);
        return carRepository.save(car);
    }

    public void deleteCar(Long id) {
        carRepository.deleteById(id);
    }


    public Car setCarAvailability(Long id, boolean availability) {
        Car car = getCarById(id);
        car.setAvailable(availability);
        return carRepository.save(car);
    }
    public List<Car> getAllCars() {
        return carRepository.findAll();
    }

}
