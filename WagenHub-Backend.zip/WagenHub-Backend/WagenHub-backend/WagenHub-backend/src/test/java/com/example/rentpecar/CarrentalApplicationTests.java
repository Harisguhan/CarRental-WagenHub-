package com.example.rentpecar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarrentalApplicationTests {

	@Test
	void contextLoads() {
	}

}
