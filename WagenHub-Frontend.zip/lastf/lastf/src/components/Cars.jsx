"use client"
import './Cars.css'
import { useState, useEffect } from "react"
import { useNavigate } from "react-router-dom"

function Cars() {
  const [cars, setCars] = useState([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const navigate = useNavigate()

  useEffect(() => {
    fetchCars()
  }, [])

  const fetchCars = async () => {
    try {
      const response = await fetch("http://localhost:8080/api/cars")
      if (response.ok) {
        const data = await response.json()
        
        const availableCars = data.filter(car => car.available)
        setCars(availableCars)
      } else {
        console.error("Failed to fetch cars")
      }
    } catch (error) {
      console.error("Error:", error)
    }
  }

  const handleBooking = (carId) => {
    navigate("/payment", { state: { carId } })
  }

  
  const showPrevCar = () => {
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? cars.length - 1 : prevIndex - 1))
  }

  
  const showNextCar = () => {
    setCurrentIndex((prevIndex) => (prevIndex === cars.length - 1 ? 0 : prevIndex + 1))
  }

  return (
    <div className="cars">
      <h2>Available Cars</h2>
      <div className="car-container">
        {}
        <button className="arrow left-arrow" onClick={showPrevCar}>&#10094;</button>

        {}
        {cars.length > 0 && (
          <div className="car-item">
            <img src={cars[currentIndex].image || "/placeholder.svg"} alt={`${cars[currentIndex].brand} ${cars[currentIndex].model}`} width="300" height="180" />
            <h3>{cars[currentIndex].brand} {cars[currentIndex].model} ({cars[currentIndex].year})</h3>
            <p><strong>Price per day:</strong> ₹{cars[currentIndex].pricePerDay}</p>
            <p><strong>Color:</strong> {cars[currentIndex].color}</p>
            <p><strong>Seats Available:</strong> {cars[currentIndex].seatsAvailable}</p>
            <p><strong>Fuel Type:</strong> {cars[currentIndex].fuelType}</p>
            <p><strong>Location:</strong> {cars[currentIndex].location}</p>
            <button onClick={() => handleBooking(cars[currentIndex].id)}>Book Now</button>
          </div>
        )}

        {}
        <button className="arrow right-arrow" onClick={showNextCar}>&#10095;</button>
      </div>
    </div>
  )
}

export default Cars
