import "./Home.css"

function Home() {
  return (
    <div className="home">
      <div className="overlay"></div>
      <img src="/logo.png" alt="WagenHub Logo" className="logo" />
      <p>Welcome to WagenHub!</p>
      <p>Find your perfect ride for your next adventure</p>
    </div>
  )
}

export default Home

