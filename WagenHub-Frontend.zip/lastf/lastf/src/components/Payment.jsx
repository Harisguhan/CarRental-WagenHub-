"use client"
import './Payment.css'

import { useState } from "react"
import { useNavigate, useLocation } from "react-router-dom"

function Payment() {
  const location = useLocation()
  const [paymentDetails, setPaymentDetails] = useState({
    carId: location.state?.carId || "",
    startDate: "",
    endDate: "",
    paymentMethod: "",
  })

  const navigate = useNavigate()

  const handleChange = (e) => {
    setPaymentDetails({ ...paymentDetails, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      
      const paymentResponse = await fetch("http://localhost:8080/api/payments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        body: JSON.stringify(paymentDetails),
      })

      if (!paymentResponse.ok) {
        throw new Error("Payment failed")
      }

      
      const carId = paymentDetails.carId
      await fetch(`http://localhost:8080/api/cars/${carId}/set-unavailable`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      })

      alert("Payment Successful!")
      navigate("/")
    } catch (error) {
      console.error("Error:", error)
      alert("Payment failed. Please try again.")
    }
  }

  return (
    <div className="payment-container">
      <div className="payment">
        <h2>Payment</h2>
        <form onSubmit={handleSubmit}>
          <div>
            <label>Start Date:</label>
            <input type="date" name="startDate" value={paymentDetails.startDate} onChange={handleChange} required />
          </div>
          <div>
            <label>End Date:</label>
            <input type="date" name="endDate" value={paymentDetails.endDate} onChange={handleChange} required />
          </div>
          <div>
            <label>Payment Method:</label>
            <select name="paymentMethod" onChange={handleChange} required>
              <option value="">Select Payment Method</option>
              <option value="credit_card">Credit Card</option>
              <option value="debit_card">Debit Card</option>
              <option value="upi">UPI</option>
              <option value="paypal">PayPal</option>
            </select>
          </div>
          <button type="submit">Pay Now</button>
        </form>
      </div>
    </div>
  )
}

export default Payment
