import './Login.css'
"use client"

import { useState } from "react"
import { useNavigate } from "react-router-dom"

function Login() {
  const [formData, setFormData] = useState({ email: "", password: "" })
  const navigate = useNavigate()

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      const response = await fetch("http://localhost:8080/api/users/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        const data = await response.json()
        localStorage.setItem("token", data.token)
        navigate("/cars")
      } else {
        const errorData = await response.json()
        alert(`Login failed: ${errorData.message}`)
      }
    } catch (error) {
      console.error("Error:", error)
      alert("An error occurred during login. Please try again.")
    }
  }

  return (
    <div className="login" style={{ backgroundColor: "#ffffff" }}>
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <input type="email" name="email" placeholder="Email" onChange={handleChange} required />
        <input type="password" name="password" placeholder="Password" onChange={handleChange} required />
        <button type="submit">Login</button>
      </form>
    </div>
  )
}

export default Login

